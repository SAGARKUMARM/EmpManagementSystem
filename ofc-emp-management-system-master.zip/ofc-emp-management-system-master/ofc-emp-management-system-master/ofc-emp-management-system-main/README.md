# ofc-emp-management-system
Python-Django project tutorial from the scratch
